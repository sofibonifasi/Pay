<?php

declare(strict_types=1);

namespace Pw\SlimApp\Repository;

use PDO;
use Pw\SlimApp\Model\User;
use Pw\SlimApp\Model\UserRepository;

final class MySQLUserRepository4 implements UserRepository
{
    private const DATE_FORMAT = 'Y-m-d H:i:s';

    private PDOSingleton $database;

    public function __construct(PDOSingleton $database)
    {
        $this->database = $database;
    }

    public function save(User $user): void
    {
        $query = <<<'QUERY'
        INSERT INTO peticiones(id, type, amount, user_id, user_ini, nomdemana)
        VALUES(:id, :type, :amount, :user_id, :user_ini, :nomdemana)
QUERY;
        $statement = $this->database->connection()->prepare($query);

        $id = $user->id();
        $type = $user->type();
        $amount = $user->amount();
        $user_id = $user->user_id();
        $uset_ini = $user->uset_ini();
        $nomdemana = $user->nomdemana();


        $statement->bindParam('id', $id, PDO::PARAM_STR);
        $statement->bindParam('type', $type, PDO::PARAM_STR);
        $statement->bindParam('amount', $amount, PDO::PARAM_STR);
        $statement->bindParam('user_id', $user_id, PDO::PARAM_STR);
        $statement->bindParam('uset_ini', $uset_ini, PDO::PARAM_STR);
        $statement->bindParam('nomdemana', $nomdemana, PDO::PARAM_STR);

        $statement->execute();
    }
}