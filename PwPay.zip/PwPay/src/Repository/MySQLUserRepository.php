<?php

declare(strict_types=1);

namespace Pw\SlimApp\Repository;

use PDO;
use Pw\SlimApp\Model\User;
use Pw\SlimApp\Model\UserRepository;

final class MySQLUserRepository implements UserRepository
{
    private const DATE_FORMAT = 'Y-m-d H:i:s';

    private PDOSingleton $database;

    public function __construct(PDOSingleton $database)
    {
        $this->database = $database;
    }

    public function save(User $user): void
    {
        $query = <<<'QUERY'
        INSERT INTO user(id, email, password, birthday, phone, profile_picture, valid, balance)
        VALUES(:id, :email, :password, :birthday, :phone, :profile_picture, :valid, :balance)
QUERY;
        $statement = $this->database->connection()->prepare($query);

        $id = $user->id();
        $email = $user->email();
        $password = $user->password();
        $birthday = $user->birthday()->format(self::DATE_FORMAT);
        $phone = $user->phone();
        $profile_picture = $user->profile_picture();

        $statement->bindParam('id', $id, PDO::PARAM_STR);
        $statement->bindParam('email', $email, PDO::PARAM_STR);
        $statement->bindParam('password', $password, PDO::PARAM_STR);
        $statement->bindParam('birthday', $birthday, PDO::PARAM_STR);
        $statement->bindParam('phone', $phone, PDO::PARAM_STR);
        $statement->bindParam('profile_picture', $profile_picture, PDO::PARAM_STR);

        $statement->execute();
    }
}