<?php

declare(strict_types=1);

namespace Pw\SlimApp\Repository;

use PDO;
use Pw\SlimApp\Model\User;
use Pw\SlimApp\Model\UserRepository;

final class MySQLUserRepository2 implements UserRepository
{
    private const DATE_FORMAT = 'Y-m-d H:i:s';

    private PDOSingleton $database;

    public function __construct(PDOSingleton $database)
    {
        $this->database = $database;
    }

    public function save(User $user): void
    {
        $query = <<<'QUERY'
        INSERT INTO company(id, owner, iban, balance, transactions, user_id)
        VALUES(:id, :owner, :iban, :balance, :transactions, :user_id)
QUERY;
        $statement = $this->database->connection()->prepare($query);


        $id = $user->id();
        $owner = $user->owner();
        $iban = $user->iban();
        $balance = $user->balance();
        $transactions = $user->transactions();
        $user_id = $user->user_id();


        $statement->bindParam('id', $id, PDO::PARAM_STR);
        $statement->bindParam('owner', $owner, PDO::PARAM_STR);
        $statement->bindParam('iban', $iban, PDO::PARAM_STR);
        $statement->bindParam('balance', $balance, PDO::PARAM_STR);
        $statement->bindParam('transactions', $transactions, PDO::PARAM_STR);
        $statement->bindParam('user_id', $user_id, PDO::PARAM_STR);



        $statement->execute();
    }
}