<?php

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Slim\Psr7\Request as Request;
use Slim\Psr7\Response as Response;
use Pw\SlimApp\Model\UserLoadMoney;
use Iban\Validation\Validator;
use PDO;

final class LoadMoneyController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }
    public function getBank(Request $request, Response $response): Response
    {
        if (!empty($_SESSION) ) {
            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT iban FROM company WHERE user_id=:id");
            $query->execute(array(
                ':id' => $id,
            ));

            $data = $query->fetchall(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $iban = $row['iban'];
            }

            if ($iban != null) {
                $conn = $this->container->get("db")->connection();
                $id = $_SESSION['id'];
                $owner = $_SESSION['email'];

                $query = $conn->prepare("SELECT profile FROM user WHERE id=:id");
                $query->execute(array(
                    ':id' => $id
                ));

                $data = $query->fetchall(PDO::FETCH_ASSOC);

                foreach ($data as $row) {
                    $data['profile'] = $row['profile'];
                }

                return $this->container->get('view')->render(
                    $response,
                    'loadMoney2.twig',
                    [
                        'owner' => $owner,
                        'iban' => $iban,
                        'formData' => $data,
                    ]
                );
            } else {
                $conn = $this->container->get("db")->connection();
                $id = $_SESSION['id'];

                $query = $conn->prepare("SELECT profile FROM user WHERE id=:id");
                $query->execute(array(
                    ':id' => $id
                ));

                $data = $query->fetchall(PDO::FETCH_ASSOC);

                foreach ($data as $row) {
                    $data['profile'] = $row['profile'];
                }

                return $this->container->get('view')->render(
                    $response,
                    'loadMoney.twig',
                    [
                        'formData' => $data,
                    ]
                );
            }
        } else {
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function bankLoad(Request $request, Response $response): Response {
        $dataIn = $request->getParsedBody();
        $errors = [];

        $conn = $this->container->get("db")->connection();
        $id = $_SESSION['id'];
        $owner = $_SESSION['email'];

        $userSendMONEY = new UserLoadMoney(
            $dataIn['send_money'] ?? '',
            $dataIn['iban'] ?? '',
            $dataIn['amount'] ?? '',
        );

        $amount = $dataIn['amount'];

        //Positive input
        if ($amount < 0) {
            $errors['amount'] = 'The amount must be a positive number.';
        }

        $query = $conn->prepare("SELECT iban, balance FROM company WHERE user_id=:id");
        $query->execute(array(
            ':id' => $id,
        ));

        $data = $query->fetchall(PDO::FETCH_ASSOC);

        foreach ($data as $row) {
            $iban = $row['iban'];
            $balance = $row['balance'];
        }

        //Imagen del perfil
        $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:id");
        $query2->execute(array(
            ':id' => $id,
        ));

        $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data2 as $row) {
            $data2['profile'] = $row['profile'];
        }

        if (empty($errors)) {
            $balance = $balance + $amount;
            $query = $conn->prepare("UPDATE company set balance=:amount where user_id=:id ");
            $query->execute(array(
                ':amount' => $balance,
                ':id' => $id,
            ));

            $query = $conn->prepare("INSERT INTO transaccions (transaction, type, origin, destination, amount) VALUES('Charged', 'charge', '$owner','$owner', '$amount')");
            $query->execute(array(
                ':transaction' => 'Charged',
                ':type' => 'charge',
                ':origin' => $owner,
                ':destination' => $owner,
                ':amount' => $amount,
            ));

            echo "<script type='text/javascript'>alert('The money was successfully added to your account.');</script>";

            return $this->container->get('view')->render(
                $response,
                'loadMoney2.twig',
                [
                    'owner' => $owner,
                    'iban' => $iban,
                    'formData' => $data2,
                ]
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'loadMoney2.twig',
                [
                    'owner' => $owner,
                    'iban' => $iban,
                    'formData' => $data2,
                    'formErrors' => $errors,
                ]
            );
        }
    }

    public function bankPost(Request $request, Response $response): Response {
        $data = $request->getParsedBody();

        $userLoad = new UserLoadMoney(
            $data['owner'] ?? '',
            $data['iban'] ?? '',
            $data['amount'] ?? ''
        );

        $this->handleFormSubmission($request,$response);

        if (!empty($data)) {
            return $response->withHeader("bank-account", "/")->withStatus(302);
        }
    }

    public function handleFormSubmission(Request $request, Response $response): Response {

        $errors = [];
        $data = $request->getParsedBody();

        $id = $_SESSION['id'];
        $owner = $_SESSION['email'];
        $validator = new Validator([]);

        $owner_name = $data['owner_name'];
        $iban = $data['iban'];

        $conn = $this->container->get("db")->connection();

        if (!$validator->validate($iban)) {
            foreach ($validator->getViolations() as $violation) {
                $errors['iban'] = $violation;
            }
        }

        if ($owner != $owner_name) {
            $errors['owner_name'] = "The owner name is incorrect.";
        }

        //Imagen de perfil
        $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:id");
        $query2->execute(array(
            ':id' => $id,
        ));

        $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data2 as $row) {
            $data2['profile'] = $row['profile'];
        }

        if(empty($errors)){
            $query = $conn->prepare("UPDATE company SET iban=:iban WHERE user_id=:id");
            $query->execute(array(
                ':id' => $id,
                ':iban' => $iban,
            ));
            $iban = substr($iban, 0, 6);
            return $this->container->get('view')->render(
                $response,
                'loadMoney2.twig',
                [
                    'owner' => $owner,
                    'iban' => $iban,
                    'formData' => $data2,
                ]
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'loadMoney.twig',
                [
                    'formData' => $data2,
                    'formErrors' => $errors
                ]
            );
        }
    }
}