<?php

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use PDO;

final class HomeController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function showHomePage(Request $request, Response $response): Response
    {
        if(!empty($_SESSION)){
            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'homeLoggedIn.twig',
                [
                    'formData' => $data,
                ]
            );
        }else{
            return $this->container->get('view')->render(
                $response,
                'home.twig',
                []
            );
        }
    }
}