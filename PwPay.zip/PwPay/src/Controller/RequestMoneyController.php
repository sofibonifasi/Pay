<?php

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Pw\SlimApp\Model\UserRequest;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use PDO;

final class RequestMoneyController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function requestGet (Request $request, Response $response): Response
    {
        if(!empty($_SESSION)){
            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'requestMoney.twig',
                [
                    'formData' => $data,
                ]
            );
        } else{
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function requestPost (Request $request, Response $response): Response
    {
        $dataIn = $request->getParsedBody();
        $errors = [];
        $email = $_SESSION['email'];

        $conn = $this->container->get("db")->connection();
        $stmt = $conn->prepare("SELECT * FROM user WHERE email=? AND valid=?");
        $stmt->execute([$dataIn['request_money_from'], '1']);
        $user = $stmt->fetch();

        $userRequest = new UserRequest(
            $data['request_money_from'] ?? '',
            $data['amount'] ?? '',
        );

        $amount = $dataIn['amount'];
        $emailDest = $dataIn['request_money_from'];

        //Positive input
        if ($amount < 0) {
            $errors['amount'] = 'The amount must be a positive number.';
        }
        //Existent user
        if (!$user) {
            $errors['request_money_from'] = 'The user you want to send money to must be an active user.';
        }
        //Same account
        if ($email == $dataIn['request_money_from']) {
            $errors['request_money_from'] = "You can't request money from yourself, choose another account.";
        }

        if (empty($errors)) {

            $email = $_SESSION['email'];
            $query = $conn->prepare("INSERT INTO peticiones (type, amount, origin, destination) VALUES('Requested', '$amount','$email', '$emailDest')");
            $query->execute(array(
                ':transaction' => 'Requested',
                ':amount' => $amount,
                ':origin' => $email,
                ':destination' => $emailDest,
            ));

            $query = $conn->prepare("INSERT INTO transaccions (transaction, type, origin, destination, amount) VALUES('Requested', 'ask', '$email','$emailDest', '$amount')");
            $query->execute(array(
                ':transaction' => 'Requested',
                ':type' => 'ask',
                ':email' => $email,
                ':emailDest' => $emailDest,
                ':amount' => $amount,
            ));

            echo "<script type='text/javascript'>alert('Your request has been made.');</script>";

            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT origin, destination, amount FROM transaccions WHERE origin=:origin OR destination=:destination ORDER BY id DESC LIMIT 5");
            $query->execute(array(
                ':origin' => $email,
                ':destination' => $email,
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            $query3 = $conn->prepare("SELECT balance FROM company WHERE user_id=:user_id");
            $query3->execute(array(
                ':user_id' => $id
            ));

            $data3 = $query3->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data3 as $row) {
                $data3['balance'] = $row['balance'];
            }

            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'dest' => $row['destination'], 'amount' => $row['amount']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'dashboard.twig',
                [
                    'formData' => $data2,
                    'dades' => $final,
                    'balanceData' => $data3,
                ]
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'requestMoney.twig',
                [
                    'formData' => $dataIn,
                    'formErrors' => $errors,
                ]
            );
        }
    }

    public function pendingGet (Request $request, Response $response): Response {
        if (!empty($_SESSION)) {
            $conn = $this->container->get("db")->connection();
            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT id, amount, origin, paid FROM peticiones WHERE (destination=:email AND paid=:paid)");
            $query->execute(array(
                ':email' => $email,
                ':paid' => 0
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);
            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'amount' => $row['amount'], 'id' => $row['id']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'requestMoney2.twig',
                [
                    'formData' => $data2,
                    'dades' => $final
                ]
            );
        } else {
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function acceptGet (Request $request, Response $response): Response {

        $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ?
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .
            $_SERVER['REQUEST_URI'];
        $parts = Explode('/', $url);
        $id = $parts[count($parts) - 2];

        $conn = $this->container->get("db")->connection();

        $query = $conn->prepare("SELECT origin, destination, amount FROM peticiones WHERE id=:id");
        $query->execute(array(
            ':id' => $id
        ));

        $data = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($data as $row){
            $origin = $row['origin'];
            $destination = $row['destination'];
            $amount = $row['amount'];
        }

        $query = $conn->prepare("SELECT balance FROM company WHERE owner=:owner");
        $query->execute(array(
            ':owner' => $destination
        ));

        $data = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($data as $row){
            $balanceDest = $row['balance'];
        }

        if($balanceDest > $amount) {

            $query = $conn->prepare("UPDATE peticiones set paid=:paid where id=:id ");
            $query->execute(array(
                ':paid' => 1,
                ':id' => $id
            ));

            $balanceDest = $balanceDest - $amount;
            $query = $conn->prepare("UPDATE company set balance=:balance where owner=:owner ");
            $query->execute(array(
                ':balance' => $balanceDest,
                ':owner' => $destination
            ));

            $query = $conn->prepare("SELECT balance FROM company WHERE owner=:owner");
            $query->execute(array(
                ':owner' => $origin
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($data as $row){
                $balanceOrigin = $row['balance'];
            }

            $balanceOrigin = $balanceOrigin + $amount;
            $query = $conn->prepare("UPDATE company set balance=:balance where owner=:owner ");
            $query->execute(array(
                ':balance' => $balanceOrigin,
                ':owner' => $origin
            ));

            $query = $conn->prepare("INSERT INTO transaccions (transaction, type, origin, destination, amount) VALUES('Paid', 'pay', '$destination','$origin', '$amount')");
            $query->execute(array(
                ':transaction' => 'Paid',
                ':type' => 'pay',
                ':origin' => $destination,
                ':destination' => $origin,
                ':amount' => $amount,
            ));

            $query2 = $conn->prepare("SELECT profile FROM user WHERE email=:email");
            $query2->execute(array(
                ':email' => $destination
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->pendingGet($request, $response);
        } else{
            $error['error'] = "You don't have enough funds to pay for this request.";

            $conn = $this->container->get("db")->connection();
            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT id, amount, origin, paid FROM peticiones WHERE (destination=:email AND paid=:paid)");
            $query->execute(array(
                ':email' => $email,
                ':paid' => 0
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);
            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'amount' => $row['amount'], 'id' => $row['id']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'requestMoney2.twig',
                [
                    'formData' => $data2,
                    'dades' => $final,
                    'error' => $error,
                ]
            );
        }
    }
}