<?php

declare(strict_types=1);

namespace Pw\SlimApp\Controller;

use DateTime;
use Exception;
use Psr\Container\ContainerInterface;
use Pw\SlimApp\Model\User;
use Pw\SlimApp\Model\UserImage;
use Pw\SlimApp\Model\UserChangePassword;
use Pw\SlimApp\Model\UserTransactions;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use PDO;


final class ProfileController
{
    private ContainerInterface $container;
    private const UNEXPECTED_ERROR = "An unexpected error occurred uploading the file '%s'...";
    private const INVALID_EXTENSION_ERROR = "The received file extension '%s' is not valid";
    private const ALLOWED_EXTENSIONS = ['png'];

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function activateProfile2 (Request $request, Response $response): Response
    {
        if(!empty($_SESSION)){

            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'profile2.twig',
                [
                    'formData' => $data,
                ]
            );

        } else {
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function profileGet(Request $request, Response $response): Response
    {
        try {
            if(!empty($_SESSION)){
                $conn = $this->container->get("db")->connection();
                $id = $_SESSION['id'];

                $query = $conn->prepare("SELECT email, birthday, phone, profile FROM user WHERE id=:user_id");
                $query->execute(array(
                    ':user_id' => $id
                ));

                $data = $query->fetchAll(PDO::FETCH_ASSOC);

                foreach ($data as $row) {
                    $data['email'] = $row['email'];
                    $data['birthday'] = $row['birthday'];
                    $data['phone'] = $row['phone'];
                    $data['profile'] = $row['profile'];
                }

                return $this->container->get('view')->render(
                    $response,
                    'profile.twig',
                    [
                        'formData' => $data,
                    ]
                );
            }else{
                echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
                return $this->container->get('view')->render(
                    $response,
                    'signIn.twig',
                    []
                );
            }
        } catch (Exception $exception) {
            echo "Error : ";
        }
    }

    public function profilePost(Request $request, Response $response): Response
    {
        $id = $_SESSION['id'];
        $conn = $this->container->get("db")->connection();
        $data = $request->getParsedBody();
        $errors = [];
        //Phone number
        $filtered_phone_number = filter_var($data['phone'], FILTER_SANITIZE_NUMBER_INT);
        //Phone number without -
        $phone_to_check = str_replace("-", "", $filtered_phone_number);
        //Phone number without +34
        $phone_without_country_code = str_replace("+34", "", $phone_to_check);
        $uploadedFiles = $request->getUploadedFiles();
        $imagearray = array();
        $uploads_dir = '../public/assets/img';
        $nameimg = $id . ".png";

        foreach ($uploadedFiles as $row) {
            $name = $row->getClientFilename();
            $size = $row->getSize();
            $type = $row->getClientMediaType();
            $dadespro = array('name' => $name, 'size' => $size);

            array_push($imagearray, $dadespro);
            $row->moveTo($uploads_dir . "/" . $nameimg);
        }

        if (!empty($data['phone']) && strlen($phone_without_country_code) != 9 || (strlen($phone_without_country_code) == 9 && $phone_without_country_code[0] != 6 && $phone_without_country_code[0] != 7) || (strlen($phone_without_country_code) == 9 && $phone_without_country_code[0] == 7 && $phone_without_country_code[1] == 0)) {
            $errors['phone'] = 'The phone number must follow the Spanish numbering plan.';
        }
        if ($size > 97953) {
            $errors['profile_picture'] = 'The file is too large.';
        }
        if ($type != "image/png") {
            $errors['profile_picture'] = 'The file must be of .png format.';
        }

        if (empty($errors)) {

            $query = $conn->prepare("UPDATE user SET profile=:nameimg WHERE id=:id");
            $query->execute(array(
                ':id' => $id,
                ':nameimg' => $nameimg
            ));

            $_SESSION['profile'] = $nameimg;

            $query = $conn->prepare("UPDATE user SET phone=:phone WHERE id=:id");
            $query->execute(array(
                ':id' => $id,
                ':phone' => $phone_without_country_code
            ));

            echo "<script type='text/javascript'>alert('Profile updated correctly.');</script>";
            return $this->profileGet($request, $response);

        } else {
            $query = $conn->prepare("SELECT email, birthday, phone, profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query ->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['email'] = $row['email'];
                $data['birthday'] = $row['birthday'];
                $data['phone'] = $row['phone'];
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'profile.twig',
                [
                    'formErrors' => $errors,
                    'formData' => $data,
                ]
            );
        }
    }

    public function updatePassword(Request $request, Response $response): Response
    {
        try {
            $errors = [];
            $conn = $this->container->get("db")->connection();
            $data = $request->getParsedBody();
            //Password validation
            $uppercase = preg_match('@[A-Z]@', $data['new_password']);
            $lowercase = preg_match('@[a-z]@', $data['new_password']);
            $number    = preg_match('@[0-9]@', $data['new_password']);

            $UserChangePassword = new UserChangePassword(
                $data['old_password'] ?? '',
                $data['new_password'] ?? '',
                $data['repeat_password'] ?? ''
            );

            $passwords = $_SESSION['password'];

            $id = $_SESSION['id'];
            $opass = $data['old_password'];
            $mpass = md5($opass);
            $npass = $data['new_password'];
            $fpass = md5($npass);
            $rpass = $data['repeat_password'];

            if ($passwords != $mpass) {
                $errors['old_password'] = 'The password is incorrect.';
            }
            if ($npass != $rpass) {
                $errors['new_password'] = "The new password and the confirmation password don't match.";
            }
            if (!$uppercase || !$lowercase || !$number || strlen($data['new_password']) < 5) {
                $errors['new_password'] = 'The new password must contain upper case letters, lower case letters, and numbers. It must also contain more than 5 characters.';
            }

            if (empty($errors)){

                $correct['correct'] = 'You have changed the password successfully.';

                $query = $conn->prepare("UPDATE user SET password=:new_password WHERE id=:id");
                $query->execute(array(
                    ':new_password' => $fpass,
                    ':id' => $id
                ));

                $_SESSION['password'] = $fpass;

                return $this->container->get('view')->render(
                    $response,
                    'profile2.twig',
                    [
                        'success' => $correct,
                    ]
                );
            } else {
                return $this->container->get('view')->render(
                    $response,
                    'profile2.twig',
                    [
                        'formErrors' => $errors,
                    ]
                );
            }
        } catch (Exception $exception) {}
    }
}
