<?php

declare(strict_types=1);

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use Pw\SlimApp\Model\User;
use Pw\SlimApp\Model\Company;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use PDO;

require '../vendor/autoload.php';

final class SignUpController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function signUpGet(Request $request, Response $response): Response
    {
        return $this->container->get('view')->render(
            $response,
            'signUp.twig',
            []
        );
    }

    public function signUpPost(Request $request, Response $response): Response
    {
        $data = $request->getParsedBody();

        $user = new User(
            $data['email'] ?? '',
            $data['password'] ?? '',
            $data['birthday'] ?? '',
            $data['phone'] ?? '',
            $data['token'] ?? ''
        );

        $company = new Company(
            $data['owner'] ?? '',
            $data['balance'] ?? '',
            $data['user_id'] ?? ''
        );

        return $this->handleFormSubmission($request,$response);
    }

    public function handleFormSubmission(Request $request, Response $response): Response
    {
        $conn = $this->container->get("db")->connection();
        $data = $request->getParsedBody();
        $errors = [];
        $email = $data['email'];
        $birthday = $data['birthday'];
        //Phone number
        $filtered_phone_number = filter_var($data['phone'], FILTER_SANITIZE_NUMBER_INT);
        //Phone number without -
        $phone_to_check = str_replace("-", "", $filtered_phone_number);
        //Phone number without +34
        $phone_without_country_code = str_replace("+34", "", $phone_to_check);
        //Over 18 validation
        $minAge = strtotime("-18 YEAR");
        $userAge = strtotime($data['birthday']);
        //Password validation
        $uppercase = preg_match('@[A-Z]@', $data['password']);
        $lowercase = preg_match('@[a-z]@', $data['password']);
        $number    = preg_match('@[0-9]@', $data['password']);
        //Email validation
        $domain = explode('@',$data['email'])[1];
        //Look for email in database
        $stmt = $conn->prepare("SELECT * FROM user WHERE email=?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        //Conditions

        //If email exists in database
        if ($user) {
            $errors['email'] = 'This user already exists.';
        }
        //Email
        if ($domain != 'salle.url.edu') {
            $errors['email'] = 'The email address must end in @salle.url.edu.';
        }
        //Password
        if (!$uppercase || !$lowercase || !$number || strlen($data['password']) < 5) {
            $errors['password'] = 'The password must contain upper case letters, lower case letters, and numbers. It must also contain more than 5 characters.';
        }
        //Age
        if ($userAge > $minAge) {
            $errors['birthday'] = 'You must be of legal age (more than 18 years) to be able to register.';
        }
        //Spanish mobile phone numbers begin with 6 or 7, followed by 8 digits (6xx xxx xxx or 7yx xxx xxx), where y can be 1 to 9, not 0 (zero).
        if (!empty($data['phone'])  && strlen($phone_without_country_code) != 9 || (strlen($phone_without_country_code) == 9 && $phone_without_country_code[0] != 6 && $phone_without_country_code[0] != 7) || (strlen($phone_without_country_code) == 9 && $phone_without_country_code[0] == 7 && $phone_without_country_code[1] == 0)) {
            $errors['phone'] = 'The phone number must follow the Spanish numbering plan.';
        }
        if(empty($errors)){
            $data['password'] = md5($data['password']);
            $password = $data['password'];
            $default = "default.png";
            $token = rand(11111111,99999999);

            $query = $conn->prepare("INSERT INTO user(email, password, birthday, phone, valid, profile, token) VALUES('$email', '$password','$birthday','$phone_without_country_code', false, '$default', '$token')");
            $query->execute(array(
                ':email' => $email,
                ':birthday' => $birthday,
                ':phone' => $phone_without_country_code,
                ':password' => $password,
                ':valid' => false,
                ':default' => $default,
                ':token' => $token
            ));

            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'mail.smtpbucket.com';
                $mail->Port = 8025;

                //Recipients
                $mail->setFrom('pwpay@pw.com', 'Mailer');
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Activate Your Account';
                $mail->Body    = '<h1>Welcome to PwPay!</h1> <p>Please click on this <a href="http://localhost:8030/activate/token='.$token.'">link</a> to activate your account.</p>';
                $mail->send();
            } catch (Exception $e) {
            }

            return $this->container->get('view')->render(
                $response,
                'pleaseValidate.twig',
                []
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'signUp.twig',
                [
                    'formErrors' => $errors,
                    'formData' => $data,
                ]
            );
        }
    }

    public function tokenGet(Request $request, Response $response): Response
    {
        $conn = $this->container->get("db")->connection();

        $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ?
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .
            $_SERVER['REQUEST_URI'];

        $end = substr($url, strrpos($url, '=') + 1);

        $stmt = $conn->prepare("SELECT id, email, valid FROM user WHERE token=?");
        $stmt->execute([$end]);
        $user = $stmt->fetch();

        if ($user) {
            $id = $user['id'];
            $email = $user['email'];
            $valid = $user['valid'];
            if($valid == '0'){
                $query = $conn->prepare("UPDATE user SET valid=:valid WHERE id=:id");
                $query->execute(array(
                    ':id' => $id,
                    ':valid' => true,
                ));

                $query = $conn->prepare("INSERT INTO company(owner, balance, user_id) VALUES('$email', '20.00','$id')");
                $query->execute(array(
                    ':owner' => $email,
                    ':balance' => 20.00,
                    ':user_id' => $id,
                ));

                return $this->container->get('view')->render(
                    $response,
                    'validated.twig',
                    []
                );
            } else {
                return $this->container->get('view')->render(
                    $response,
                    'alreadyValid.twig',
                    []
                );
            }
        } else {
            return $this->container->get('view')->render(
                $response,
                'home.twig',
                []
            );
        }
    }
}

