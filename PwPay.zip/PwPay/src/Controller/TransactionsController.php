<?php
declare(strict_types=1);

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Pw\SlimApp\Model\UserTransactions;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use PDO;

final class TransactionsController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;

    }

    public function transactions(Request $request, Response $response): Response
    {
        try {
            if(!empty($_SESSION)){
                $conn = $this->container->get("db")->connection();

                $email = $_SESSION['email'];
                $id = $_SESSION['id'];

                $query = $conn->prepare("SELECT id, transaction, origin, destination, amount FROM transaccions WHERE (origin=:origin OR destination=:destination) ORDER BY id DESC");
                $query->execute(array(
                    ':origin' => $email,
                    ':destination' => $email,
                ));

                $data = $query->fetchAll(PDO::FETCH_ASSOC);

                $final = array();

                foreach ($data as $row) {
                    $dades = (object) array('transaction' => $row['transaction'],'origin' => $row['origin'], 'destination' => $row['destination'], 'amount' => $row['amount']);
                    array_push($final, $dades);
                }

                $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
                $query2->execute(array(
                    ':user_id' => $id
                ));

                $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

                foreach ($data2 as $row) {
                    $data2['profile'] = $row['profile'];
                }

                return $this->container->get('view')->render(
                    $response,
                    'transactions.twig',
                    [
                        'formData' => $data2,
                        'dades' => $final
                    ]
                );
            } else {
                echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
                return $this->container->get('view')->render(
                    $response,
                    'signIn.twig',
                    []
                );
            }
        } catch (Exception $exception) {}
    }
}