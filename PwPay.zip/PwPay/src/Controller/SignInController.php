<?php

declare(strict_types=1);

namespace Pw\SlimApp\Controller;

use DateTime;
use Exception;
use Psr\Container\ContainerInterface;
use Pw\SlimApp\Model\UserIn;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use Pw\SlimApp\Repository\MySQLUserRepository;
use PDO;

final class SignInController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function signInGet(Request $request, Response $response): Response
    {
        if(!empty($_SESSION)){
            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'signInLoggedIn.twig',
                [
                    'formData' => $data,
                ]
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function signInPost(Request $request, Response $response): Response
    {
        try {
            $data = $request->getParsedBody();

            $userIn = new UserIn(
                $data['email'] ?? '',
                $data['password'] ?? '',
            );

            $this->handleFormSubmission($request,$response);

            if (!empty($data)) {
                return $response->withHeader("sign-in", "/")->withStatus(302);
            }
        } catch (Exception $exception) {}

        return $this->handleFormSubmission($request,$response);
    }

    public function logOut(Request $request, Response $response): Response
    {
        unset($_SESSION['id']);
        unset($_SESSION['email']);
        unset($_SESSION['password']);
        unset($_SESSION['profile']);
        unset($_SESSION['dades']);
        return $response->withHeader("Location", "/")->withStatus(302);
    }

    public function handleFormSubmission(Request $request, Response $response): Response
    {
        $data = $request->getParsedBody();
        $errors = [];
        $conn = $this->container->get("db")->connection();
        $email = $data['email'];
        //Busca si el usuario existe y si está validado
        $stmt = $conn->prepare("SELECT * FROM user WHERE email=? AND valid=?");
        $stmt->execute([$email, 1]);
        $user = $stmt->fetch();
        $data['password'] = md5($data['password']);
        $password = $data['password'];
        //Busca la contraseña del usuario y la compara con la insertada
        $passwordUser = $conn->prepare("SELECT id FROM user WHERE email=? AND password =?");
        $passwordUser->execute([$email, $password]);
        $pwd = $passwordUser->fetchAll(PDO::FETCH_ASSOC);

        //Si el usuario no existe o no está validado
        if (!$user) {
            $errors['email'] = "This user does not exist or hasn't been validated yet.";
        }
        //Si la contraseña no coincide
        if (!$pwd) {
            $errors['password'] = 'The password is incorrect.';
        }
        if(empty($errors)){

            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;

            foreach ($pwd as $row){
                $_SESSION['id'] = $row['id'];
            }

            $conn = $this->container->get("db")->connection();

            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT origin, destination, amount FROM transaccions WHERE origin=:origin OR destination=:destination ORDER BY id DESC LIMIT 5");
            $query->execute(array(
                ':origin' => $email,
                ':destination' => $email,
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            $query3 = $conn->prepare("SELECT balance FROM company WHERE user_id=:user_id");
            $query3->execute(array(
                ':user_id' => $id
            ));

            $data3 = $query3->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data3 as $row) {
                $data3['balance'] = $row['balance'];
            }

            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'dest' => $row['destination'], 'amount' => $row['amount']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'dashboard.twig',
                [
                    'formData' => $data2,
                    'dades' => $final,
                    'balanceData' => $data3,
                ]
            );
        } else {
            $data = $request->getParsedBody();
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                [
                    'formErrors' => $errors,
                    'formData' => $data,
                ]
            );
        }
    }
}