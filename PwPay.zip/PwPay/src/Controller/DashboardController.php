<?php

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Pw\SlimApp\Model\User;
use PDO;

final class DashboardController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function dashGet(\Slim\Psr7\Request $request, \Slim\Psr7\Response $response): Response
    {
        if(!empty($_SESSION)){
            $conn = $this->container->get("db")->connection();

            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT origin, destination, amount FROM transaccions WHERE origin=:origin OR destination=:destination ORDER BY id DESC LIMIT 5");
            $query->execute(array(
                ':origin' => $email,
                ':destination' => $email,
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            $query3 = $conn->prepare("SELECT balance FROM company WHERE user_id=:user_id");
            $query3->execute(array(
                ':user_id' => $id
            ));

            $data3 = $query3->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data3 as $row) {
                $data3['balance'] = $row['balance'];
            }

            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'dest' => $row['destination'], 'amount' => $row['amount']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'dashboard.twig',
                [
                    'formData' => $data2,
                    'dades' => $final,
                    'balanceData' => $data3,
                ]
            );
        }else{
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }
}