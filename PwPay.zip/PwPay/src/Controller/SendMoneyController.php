<?php

namespace Pw\SlimApp\Controller;

use Psr\Container\ContainerInterface;
use Pw\SlimApp\Model\UserSendMoney;
use Slim\Psr7\Request;
use Slim\Psr7\Response;
use PDO;

final class SendMoneyController
{
    private ContainerInterface $container;

    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    public function sendGet (Request $request, Response $response): Response
    {
        if(!empty($_SESSION)){
            $conn = $this->container->get("db")->connection();
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query->execute(array(
                ':user_id' => $id
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data as $row) {
                $data['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'sendMoney.twig',
                [
                    'formData' => $data,
                ]
            );
        }else{
            echo "<script type='text/javascript'>alert('You need to be logged in in order to access this page.');</script>";
            return $this->container->get('view')->render(
                $response,
                'signIn.twig',
                []
            );
        }
    }

    public function sendPost(Request $request, Response $response): Response
    {
        $dataIn = $request->getParsedBody();
        $errors = [];

        $conn = $this->container->get("db")->connection();
        $id = $_SESSION['id'];
        $email = $_SESSION['email'];
        $stmt = $conn->prepare("SELECT * FROM user WHERE email=? AND valid=?");
        $stmt->execute([$dataIn['send_money'], '1']);
        $user = $stmt->fetch();

        $userSendMONEY = new UserSendMoney(
            $data['send_money'] ?? '',
            $data['amount'] ?? '',
        );

        $amount = $dataIn['amount'];

        $query = $conn->prepare("SELECT balance FROM company WHERE user_id=:id");
        $query->execute(array(
            ':id' => $id
        ));

        $data = $query->fetchall(PDO::FETCH_ASSOC);

        foreach ($data as $row) {
            $balance = $row['balance'];
        }

        //Positive input
        if ($amount < 0) {
            $errors['amount'] = 'The amount must be a positive number.';
        }
        //Same account
        if ($email == $dataIn['send_money']) {
            $errors['send_money'] = "You can't send money to yourself, choose another account.";
        }
        //Existent user
        if (!$user) {
            $errors['send_money'] = 'The user you want to send money to must be an active user.';
        }
        //Enough Money
        if ($amount > $balance) {
            $errors['amount'] = "You don't have enough money to make the transfer.";
        }

        if (empty($errors)) {

            $balance = $balance - $amount;

            $query = $conn->prepare("UPDATE company set balance=:amount where user_id=:id ");
            $query->execute(array(
                ':amount' => $balance,
                ':id' => $id,
            ));

            $query2 = $conn->prepare("SELECT email FROM user WHERE id=:id");
            $query2->execute(array(
                ':id' => $id
            ));

            $data2 = $query2->fetchall(PDO::FETCH_ASSOC);
            foreach ($data2 as $row) {
                $email = $row['email'];
            }
            $emailDest = $dataIn['send_money'];

            $query3 = $conn->prepare("SELECT user_id, balance FROM company WHERE owner=:owner");
            $query3->execute(array(
                ':owner' => $emailDest,
            ));

            $data3 = $query3->fetchall(PDO::FETCH_ASSOC);
            foreach ($data3 as $row) {
                $idDest = $row['user_id'];
                $balanceDest = $row['balance'];
                $balanceDest = $balanceDest + $amount;
            }

            $query = $conn->prepare("UPDATE company set balance=:amount where user_id=:id");
            $query->execute(array(
                ':amount' => $balanceDest,
                ':id' => $idDest,
            ));

            $query = $conn->prepare("INSERT INTO transaccions (transaction, type, origin, destination, amount) VALUES('Sent', 'add', '$email','$emailDest', '$amount')");
            $query->execute(array(
                ':transaction' => 'Sent',
                ':type' => 'add',
                ':email' => $email,
                ':emailDest' => $emailDest,
                ':amount' => $amount,
            ));

            echo "<script type='text/javascript'>alert('The money was sent successfully.');</script>";

            $email = $_SESSION['email'];
            $id = $_SESSION['id'];

            $query = $conn->prepare("SELECT origin, destination, amount FROM transaccions WHERE origin=:origin OR destination=:destination ORDER BY id DESC LIMIT 5");
            $query->execute(array(
                ':origin' => $email,
                ':destination' => $email,
            ));

            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            $query3 = $conn->prepare("SELECT balance FROM company WHERE user_id=:user_id");
            $query3->execute(array(
                ':user_id' => $id
            ));

            $data3 = $query3->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data3 as $row) {
                $data3['balance'] = $row['balance'];
            }

            $final = array();

            foreach ($data as $row) {
                $dades = (object) array('origin' => $row['origin'],'dest' => $row['destination'], 'amount' => $row['amount']);
                array_push($final, $dades);
            }

            $query2 = $conn->prepare("SELECT profile FROM user WHERE id=:user_id");
            $query2->execute(array(
                ':user_id' => $id
            ));

            $data2 = $query2->fetchAll(PDO::FETCH_ASSOC);

            foreach ($data2 as $row) {
                $data2['profile'] = $row['profile'];
            }

            return $this->container->get('view')->render(
                $response,
                'dashboard.twig',
                [
                    'formData' => $data2,
                    'dades' => $final,
                    'balanceData' => $data3,
                ]
            );
        } else {
            return $this->container->get('view')->render(
                $response,
                'sendMoney.twig',
                [
                    'formData' => $dataIn,
                    'formErrors' => $errors,
                ]
            );
        }
    }
}