<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserRequest
{
    private string $request_money_from;
    private string $amount;


    public function __construct(
        string $request_money_from,
        string $amount)
    {
            $this->request_money_from = $request_money_from;
            $this->amount = $amount;
    }

    public function request_money_from(): string
    {
        return $this->request_money_from;
    }
    public function setRequest_money_from(string $request_money_from): self
    {
        $this->request_money_from = $request_money_from;
        return $this;
    }

    public function amount(): string
    {
        return $this->amount;
    }
    public function setAmount(string $amount): self
    {
        $this->amount = $amount;
        return $this;
    }


}
