<?php


declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;




final class UserChangePassword
{

    private string $old_password;
    private string $new_password;
    private string $repeat_password;

    public function __construct(

        string $old_password,
        string $new_password,
        string $repeat_password

    ) {

        $this->old_password = $old_password;
        $this->new_password = $new_password;
        $this->repeat_password = $repeat_password;
    }

    public function old_password(): string
    {
        return $this->old_password;
    }
    public function setOld_Password(string $old_password): self
    {

        $this->old_password = $old_password;
        return $this;
    }
    public function new_password(): string
    {
        return $this->new_password;
    }
    public function setNew_Password(string $new_password): self
    {

        $this->new_password = $new_password;
        return $this;
    }
    public function repeat_password(): string
    {
        return $this->repeat_password;
    }
    public function setRepeat_Password(string $repeat_password): self
    {

        $this->repeat_password = $repeat_password;
        return $this;
    }
}