<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class User
{

    private string $password;


    public function __construct(
          string $password

    ) {

        $this->password = $password;

    }

    public function password(): string
    {
        return $this->password;
    }
    public function setPassword(string $password): self
    {

        $this->password = $password;
        return $this;
    }
}