<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserTransactions
{
    private int $id;
    private string $origin;
    private string $destination;
    private string $amount;

    public function __construct(
        int $id,
        string $origin,
        string $destination,
        string $amount
    ) {
        $this->id = $id;
        $this->origin = $origin;
        $this->destination = $destination;
        $this->amount = $amount;
    }

    public function id(): int
    {
        return $this->id;
    }
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function origin(): string
    {
        return $this->origin;
    }
    public function setOrigin(string $origin): self
    {
        $this->origin = $origin;
        return $this;
    }

    public function destination(): string
    {
        return $this->destination;
    }
    public function setDestination(string $destination): self
    {
        $this->destination = $destination;
        return $this;
    }

    public function amount(): string
    {
        return $this->amount;
    }
    public function setAmount(string $amount): self
    {
        $this->amount = $amount;
        return $this;
    }
}