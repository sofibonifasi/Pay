<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserImage
{

    private File $profile;

    public function __construct(

        File $profile
    ) {

        $this->profile = $profile;
    }

    public function profile(): file
    {
        return $this->profile;
    }
    public function setProfile(File $profile): self
    {
        $this->profile = $profile;
        return $this;
    }
}