<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class User
{
    private int $id;
    private string $email;
    private string $password;
    private string $birthday;
    private string $phone;
    private string $token;
    //private bool $valid;
    //private File $profile;

    public function __construct(
        string $email,
        string $password,
        string $birthday,
        string $phone,
        string $token
        //bool $valid
    ) {
        $this->email = $email;
        $this->password = $password;
        $this->birthday = $birthday;
        $this->phone = $phone;
        $this->token = $token;
        //$this->valid = $valid;
    }

    public function id(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function email(): string
    {
        return $this->email;
    }
    public function setEmail(string $email): self
    {
        $this->email = $email;
        return $this;
    }

    public function password(): string
    {
        return $this->password;
    }
    public function setPassword(string $password): self
    {

        $this->password = $password;
        return $this;
    }
    public function birthday(): string
    {
        return $this->birthday;
    }
    public function setBirthday(string $birthday): self
    {
        $this->birthday = $birthday;
        return $this;
    }
    public function phone(): string
    {
        return $this->phone;
    }
    public function setPhone(string $phone): self
    {
        $this->phone = $phone;
        return $this;
    }

    public function token(): string
    {
        return $this->token;
    }
    public function setToken(string $token): self
    {
        $this->token = $token;
        return $this;
    }
/*
    public function valid(): bool
    {
        return $this->valid;
    }
    public function setValid(bool $valid): self
    {
        $this->valid = $valid;
        return $this;
    }
*/
}