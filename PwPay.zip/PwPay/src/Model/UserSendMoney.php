<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserSendMoney
{

    private string $send_money;
    private string $amount;


    public function __construct(
        string $send_money,
        string $amount


    ) {
        $this->send_money = $send_money;
        $this->amount = $amount;

    }



    public function send_money(): string
    {
        return $this->send_money;
    }
    public function setSend_money(string $send_money): self
    {
        $this->send_money = $send_money;
        return $this;
    }
    public function amount(): string
    {
        return $this->amount;
    }

    public function setAmount(string $amount): self
    {
        $this->amount = $amount;
        return $this;
    }

}