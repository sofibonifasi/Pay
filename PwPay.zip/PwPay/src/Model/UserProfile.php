<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserProfile
{
    private int $id;
    private string $email;
    private string $password;
    private string $birthday;
    private string $phone;
    private File $profile;

    public function __construct(
        string $email,
        string $password,
        string $birthday,
        string $phone,
        File $profile
    ) {
        $this->email = $email;
        $this->password = $password;
        $this->birthday = $birthday;
        $this->phone = $phone;
        $this->profile = $profile;
    }

    public function id(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function email(): string
    {
        return $this->email;
    }
    public function setEmail(string $email): self
    {
        $this->email = $email;
        return $this;
    }


    public function birthday(): string
    {
        return $this->birthday;
    }
    public function setBirthday(string $birthday): self
    {
        $this->birthday = $birthday;
        return $this;
    }
    public function phone(): string
    {
        return $this->phone;
    }
    public function setPhone(string $phone): self
    {
        $this->phone = $phone;
        return $this;
    }
    public function profile(): file
     {
         return $this->profile;
     }
     public function setProfile(File $profile): self
     {
         $this->profile = $profile;
         return $this;
     }
}