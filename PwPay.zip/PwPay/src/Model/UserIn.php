<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class UserIn
{
    private int $id;
    private string $email;


    public function __construct(
        string $email,
        string $password

    ) {
        $this->email = $email;
        $this->password = $password;

    }

    public function id(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function email(): string
    {
        return $this->email;
    }
    public function setEmail(string $email): self
    {
        $this->email = $email;
        return $this;
    }

    public function password(): string
    {
        return $this->password;
    }
    public function setPassword(string $password): self
    {

        $this->password = $password;
        return $this;
    }

}
