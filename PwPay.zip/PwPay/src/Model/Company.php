<?php

declare(strict_types=1);

namespace Pw\SlimApp\Model;

use Cassandra\Date;
use DateTime;
use PhpParser\Node\Expr\Cast\Int_;
use PhpParser\Node\Scalar\MagicConst\File;

final class Company
{
    private int $id;
    private string $owner;
    private string $balance;
    private string $user_id;

    public function __construct(
        string $owner,
        string $balance,
        string $user_id
    ) {
        $this->owner = $owner;
        $this->balance = $balance;
        $this->user_id = $user_id;
    }

    public function id(): int
    {
        return $this->id;
    }
    public function setId(int $id): self
    {
        $this->id = $id;
        return $this;
    }

    public function owner(): string
    {
        return $this->owner;
    }
    public function setOwner(string $owner): self
    {
        $this->owner = $owner;
        return $this;
    }

    public function balance(): string
    {
        return $this->balance;
    }
    public function setBalance(string $balance): self
    {
        $this->balance = $balance;
        return $this;
    }

    public function userId(): string
    {
        return $this->user_id;
    }
    public function setUserId(string $user_id): self
    {
        $this->user_id = $user_id;
        return $this;
    }
}