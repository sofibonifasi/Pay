<?php

use Pw\SlimApp\Controller\DashboardController;
use Pw\SlimApp\Controller\HomeController;
use Pw\SlimApp\Controller\RequestMoneyController;
use Pw\SlimApp\Controller\SendMoneyController;
use Pw\SlimApp\Controller\SignInController;
use Pw\SlimApp\Controller\ProfileController;
use Pw\SlimApp\Controller\LoadMoneyController;
use Pw\SlimApp\Controller\SignUpController;
use Pw\SlimApp\Controller\TransactionsController;
use Pw\SlimApp\Controller\VisitsController;
use Pw\SlimApp\Controller\CookieMonsterController;
use Pw\SlimApp\Controller\FlashController;
use Pw\SlimApp\Controller\PostUserController;
use Pw\SlimApp\Middleware\StartSessionMiddleware;

$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ?
        "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .
    $_SERVER['REQUEST_URI'];
$token = substr($url, strrpos($url, '=') + 1);
$parts = Explode('/', $url);
$id = $parts[count($parts) - 2];

$app->add(StartSessionMiddleware::class);

$app->get(
    '/',
    HomeController::class . ":showHomePage"
)->setName('home');

$app->get(
    '/visits',
    VisitsController::class . ":showVisits"
)->setName('visits');

$app->get(
    '/cookies',
    CookieMonsterController::class . ":showAdvice"
)->setName('cookies');

$app->get(
    '/flash',
    FlashController::class . ":addMessage"
)->setName('flash');

$app->post(
    '/users',
    PostUserController::class . ":create"
)->setName('create_user');
$app->get(
    '/sign-in',
    SignInController::class . ":signInGet"
)->setName('sign-in');
$app->post(
    '/sign-in',
    SignInController::class . ":signInPost"
)->setName('sign-in');
$app->get(
    '/logout',
    SignInController::class . ":logOut"
)->setName('logOut');
$app->get(
    '/profile',
    ProfileController::class . ":profileGet"
)->setName('profileGet');
$app->post(
    '/profile',
    ProfileController::class . ":profilePost"
)->setName('profilePost');
$app->get(
    '/account/bank-account',
    LoadMoneyController::class . ":getBank"
)->setName('getBank');
$app->post(
    '/account/bank-account',
    LoadMoneyController::class . ":bankPost"
)->setName('bankPost');
$app->post(
    '/account/bank-account/load',
    LoadMoneyController::class . ":bankLoad"
)->setName('bankLoad');
$app->get(
    '/sign-up',
    SignUpController::class . ":signUpGet"
)->setName('sign-up');
$app->post(
    '/sign-up',
    SignUpController::class . ":signUpPost"
)->setName('sign-up');

$app->get(
    '/activate/token=' . $token,
    SignUpController::class . ":tokenGet"
)->setName('tokenGet');

$app->get(
    '/account/transactions',
    TransactionsController::class . ":transactions"
)->setName('transactions');
$app->post(
    '/profile/security',
    ProfileController::class . ":updatePassword"
)->setName('updatePassword');
$app->get(
    '/profile/security',
    ProfileController::class . ":activateProfile2"
)->setName('activateProfile2');
$app->get(
    '/account/summary',
    DashboardController::class . ":dashGet"
)->setName('dashGet');
$app->get(
    '/account/money/send',
    SendMoneyController::class . ":sendGet"
)->setName('sendMoneyGet');
$app->post(
    '/account/money/send',
    SendMoneyController::class . ":sendPost"
)->setName('sendMoneyPost');
$app->get(
    '/account/money/requests',
    RequestMoneyController::class . ":requestGet"
)->setName('requestGet');
$app->post(
    '/account/money/requests',
    RequestMoneyController::class . ":requestPost"
)->setName('requestPost');
$app->get(
    '/account/money/requests/pending',
    RequestMoneyController::class . ":pendingGet"
)->setName('pendingGet');
$app->get(
    '/account/money/requests/'.$id.'/accept',
    RequestMoneyController::class . ":acceptGet"
)->setName('acceptGet');
